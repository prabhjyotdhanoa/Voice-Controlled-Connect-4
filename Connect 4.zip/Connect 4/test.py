import graphics
input = win.getKey()
